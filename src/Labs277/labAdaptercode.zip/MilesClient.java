public class MilesClient {
    public double distance(double mph,double hours){
       //create a new MtoKAdapter instance
       //call its distance method
       return //distance in miles
    }
}
