package adapterlab;


/**
* The RoundPeg class.
* This is the Adaptee class.
*/
public class RoundPeg {
  public void insertIntoHole(String msg) {
   System.out.println("RoundPeg insertIntoHole(): " + msg);}
}
