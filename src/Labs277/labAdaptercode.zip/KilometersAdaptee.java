public class KilometersAdaptee {
    public double distancek(double kph,double hours) {
        return kph*hours;
    }
}
